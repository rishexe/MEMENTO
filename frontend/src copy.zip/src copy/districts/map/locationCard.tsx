import { useState } from "react";
import VisitLogger,{ type VisitPayload } from "../../visitlog/VisitLogger";
import "./locationCard.css";

function LocationCard({ location, onClose }: any) {
    const [showVisitLogger, setShowVisitLogger] = useState(false);

    if (showVisitLogger) {
        return (
            <VisitLogger
                locationName={location.name}
                locationMeta={location.category}
                locationImage={location.image}
                onCancel={() => setShowVisitLogger(false)}
                onSubmit={(payload: VisitPayload) => {
                    console.log("Visit logged:", payload);
                }}
            />
        );
    }

    return (
        <div className="location-card">
            {/* ... */}

            <button
                type="button"
                className="explore-button"
                onClick={() => setShowVisitLogger(true)}
            >
                Explore Location
            </button>
        </div>
    );
}

export default LocationCard;